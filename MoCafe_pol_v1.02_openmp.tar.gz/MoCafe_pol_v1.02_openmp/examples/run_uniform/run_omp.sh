#!/bin/bash

EXEC=../../MoCafe_pol.x

$EXEC uniform_tau10_hgg00_a10.in
$EXEC uniform_tau10_hgg02_a05.in
