#!/bin/bash

EXEC=../../MoCafe_pol.x

$EXEC b040_point_tau50_hgg02_a05.in
$EXEC point_tau10_hgg00_a10.in
$EXEC point_tau10_hgg02_a05.in
$EXEC point_tau10_hgg02_a10.in
$EXEC point_tau10_hgg04_a05.in
$EXEC point_tau10_R.in
