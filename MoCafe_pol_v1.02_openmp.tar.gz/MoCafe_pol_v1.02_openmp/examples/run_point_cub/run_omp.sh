#!/bin/bash

EXEC=../../MoCafe_pol.x

#$EXEC b040_point_tau50_hgg02_a05.in
$EXEC cub111_rot000_tau50_hgg00_a10.in
$EXEC cub111_rot045_tau50_hgg00_a10.in
$EXEC cub111_rot090_tau50_hgg00_a10.in
$EXEC cub111_rot135_tau50_hgg00_a10.in
$EXEC cub111_rot180_tau50_hgg00_a10.in
